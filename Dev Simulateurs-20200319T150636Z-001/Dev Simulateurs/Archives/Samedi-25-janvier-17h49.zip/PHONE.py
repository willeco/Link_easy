#!/usr/bin/env python
# -*-coding:Latin-1 -*

import socket
import sys
import lib_UDP

# -----------------------------------------------------------------------------
# Preparation de l'objet UDP
# -----------------------------------------------------------------------------
udp_obj = lib_UDP.LinkyUDP()

# -----------------------------------------------------------------------------
# Sent of message of wake-up to Linky
# -----------------------------------------------------------------------------
udp_obj.smartphone_ask_teleinfo_to_erlinky()

# -----------------------------------------------------------------------------
# Creation socket UDP pour recevoir la téléinfomation
# -----------------------------------------------------------------------------
# https://python.doctor/page-reseaux-sockets-python-port
# https://www.lifewirep.com/ping-command-2618099
# 
address         = "erlinky.home"
address         = "localhost"
port            = udp_obj.get_port_ER2phone()

server_address  = (address, port )
s               = socket.socket(socket.AF_INET, socket.SOCK_DGRAM )
s.bind(server_address)

print("[*] En attente de messages du compteur Linky sur le port Rx %d" % port)
while True:
    # Limiter la taille a 8176 octets
    data, address = s.recvfrom ( 4096 )
    print("[*] Recu message %s depuis %s (Port Tx=%d)" % ( data, address[0], address[1] ) )
    #print("[*] Data = %s " % data)

s.close()


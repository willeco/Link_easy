#!/usr/bin/env python
# -*-coding:Latin-1 -*

from threading import Thread
from time      import sleep
from tkinter   import *  

import sys
import json 
import lib_linky_data
import lib_UDP

#from PIL import ImageTk, Image



class InterfaceLinky(Frame):
   
    # ------------------------------------------------------------------ 
    # Initialisation Interface : Creation Widgets
    # ------------------------------------------------------------------
    def __init__(self, fenetre):

        Frame.__init__(self, fenetre, width=500, height=500)
        fenetre.title('Compteur Linky')

        # Préparation donnees linky dans un fichier
        self.linky_data = lib_linky_data.LinkyData()   
        
        # Préparation class UDP
        self.udp        = lib_UDP.LinkyUDP()

        # Creation des widgets
        self.creation_widgets()


        # Initialisation de la variable d'état stop et du thread
        self._thread, self._stop = None, True


    def creation_widgets(self):

        self.entry_width = 17

        # Création des variables interface Homme Machine 
        self.var_add_ip_source       = StringVar()
        self.var_add_ip_dest         = StringVar()
        self.var_port_ER2phone       = StringVar()
        self.var_port_phone2ER       = StringVar()
        self.var_puissance_apparente = StringVar()
        self.var_label_teleinfo      = StringVar()
        self.var_value_teleinfo      = StringVar()

        # Affectation des variables de l'IHM par défault
        self.var_add_ip_source.set("localhost")
        self.var_add_ip_dest.set("localhost")
        self.var_port_ER2phone.set(self.udp.get_port_ER2phone() )
        self.var_port_phone2ER.set(self.udp.get_port_phone2ER() )
        self.var_puissance_apparente.set("?")
        
        # Creation Label : Etat de connection et Affichage Label dans la fenetre
        self.widget_label_etat_connection   = Label(self, text="non connecté à la livebox")
        
        # Creation Entry et Label : Adresse IP et Port de Destination
        self.widget_label_add_ip_source   = Label(self, text="@ IP module radio") 
        self.widget_label_add_ip_dest     = Label(self, text="@ IP smarphone") 
        self.widget_label_port_ER2phone   = Label(self, text="Port ER vers smarphone") 
        self.widget_label_port_phone2ER   = Label(self, text="Port smarphone vers ER") 
        self.widget_label_papp            = Label(self, text="Puissance apparente (V.A)") 
        self.widget_entry_add_ip_source   = Entry(self, width=self.entry_width, textvariable=self.var_add_ip_source   ) 
        self.widget_entry_add_ip_dest     = Entry(self, width=self.entry_width, textvariable=self.var_add_ip_dest     ) 
        self.widget_entry_port_ER2phone   = Entry(self, width=self.entry_width, textvariable=self.var_port_ER2phone   ) 
        self.widget_entry_port_phone2ER   = Entry(self, width=self.entry_width, textvariable=self.var_port_phone2ER   ) 
        self.widget_entry_papp            = Entry(self, width=self.entry_width, textvariable=self.var_puissance_apparente ) 
        self.widget_entry_label_teleinfo  = Entry(self, width=self.entry_width, textvariable=self.var_label_teleinfo )
        self.widget_entry_value_teleinfo  = Entry(self, width=self.entry_width, textvariable=self.var_value_teleinfo )

        # Creation des Widgets Label Etat envoi Trame
        self.widget_label_etat_trame      = Label(self, text="Aucune trame transmise")

        # Création des Widgets Bouton ON, OFF
        self.widget_on_button             = Button(self, text="Power ON",  command=self.callback_on)
        self.widget_off_button            = Button(self, text="Power OFF", command=self.callback_off)
        self.widget_on_button.config( width=self.entry_width-3)
        self.widget_off_button.config(width=self.entry_width-3)
        
        # Création d'un Widget représentant le Compteur Linky 
        self.can    = Canvas(fenetre, width=270, height=420, background="lawn green")
        rect1       = self.can.create_rectangle(60,100,200,300, fill="light grey")
        rect2       = self.can.create_rectangle(80,150,180,250, fill="snow4")
        text1       = self.can.create_text(130, 50, text="Linky", fill="snow4", font=("Purisa, 20") )


        # Les deux lignes suivantes ne fonctionnent pas 
        # Pas possible d'afficher la photo d'un compteur Linky :-(       
        # image_linky = PhotoImage( file="linky.png")
        # img         = self.can.create_image(30,30,image=image_linky, anchor=CENTER)
    
        # Positionnement des widgets
        self.grid()
        ind_row = 0
        self.widget_label_add_ip_source.grid(    row=ind_row,  column=0, sticky = W)
        self.widget_entry_add_ip_source.grid(    row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_add_ip_dest.grid(      row=ind_row,  column=0, sticky = W)
        self.widget_entry_add_ip_dest.grid(      row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_port_ER2phone.grid(    row=ind_row,  column=0, sticky = W)
        self.widget_entry_port_ER2phone.grid(    row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_port_phone2ER.grid(    row=ind_row,  column=0, sticky = W)
        self.widget_entry_port_phone2ER.grid(    row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_papp.grid(             row=ind_row,  column=0, sticky = W)
        self.widget_entry_papp.grid(             row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_entry_label_teleinfo.grid(   row=ind_row,  column=0, sticky = E)
        self.widget_entry_value_teleinfo.grid(   row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_on_button.grid(              row=ind_row,  column=0, sticky = E)
        self.widget_off_button.grid(             row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_etat_connection.grid(  row=ind_row,  columnspan = 2)
        ind_row += 1
        self.widget_label_etat_trame.grid(       row=ind_row,  columnspan = 2)
        ind_row += 1

        self.can.grid( row = ind_row )

    # ------------------------------------------------------------------------- 
    # Call-back ON (fonction appelée lors de l'appui sur le bouton ON)
    # -------------------------------------------------------------------------
    def callback_on(self):
        
        # Si Thread jamais ete cree
        if self._thread is None:
            
            self._stop   = False
            # Creation du Thread : la fonction action sera appelee
            self._thread = Thread(target=self.action)
            
            # Demarrage du Thread
            self._thread.start()
        
 
    # ------------------------------------------------------------------------- 
    # Call-back OFF (fonction appelée lors de l'appui sur le bouton OFF)
    # -------------------------------------------------------------------------
    def callback_off(self):
        if self._thread is not None:
            self._thread, self._stop = None, True

    # ------------------------------------------------------------------------- 
    # Call-back action (Thread crée lors de l'appui sur le bouton ON)
    # -------------------------------------------------------------------------
    def action(self):
        
        # Attente requete en provenance du smartphone (bloquant)
        self.widget_label_etat_connection["text"] = "Attente requête du smartphone ..."
        self.udp.waiting_message_from_smartphone()
        self.widget_label_etat_connection["text"] = "Requête reçu du smartphone "
        
        while True:
            i = 0
            for teleinfo in self.linky_data.get_teleinfo():

                # Arret boucle si demandé par l'utilisation
                if self._stop:
                    break

                # Recupération téléinformation au format Json
                json_tele = json.loads(teleinfo)

                # Boucle sur les clés (normalement, il n'y a qu'une)
                for cle in json_tele.keys():

                    # Affichage de la téléinformation sur l'interface
                    self.var_label_teleinfo.set(cle)
                    self.var_value_teleinfo.set(json_tele[cle])

                    # Identification Puissance apparente et affichage
                    if cle == "PAPP":
                        #print()
                        self.var_puissance_apparente.set( json_tele[cle] )
                        self.udp.send_teleinfo(str(json.dumps(json_tele)), self.var_add_ip_dest.get(), self.var_port_ER2phone.get() )
                        
                # Extraction étiquette  téléinfo

                # Extraction valeur téléinfo

                # Mise à jour nombre champs teleinfo traités
                self.widget_label_etat_trame["text"] = "Playing... (count: {})".format(i)

                # Pause 
                sleep(0.01)
                i+= 1
            
        self.widget_label_etat_trame["text"] = "Stopped."
        
# -----------------------------------------------------------------------------
# Test
# ----------------------------------------------------------------------------- 
if __name__ == '__main__':
    fenetre     = Tk()
    linky       = InterfaceLinky(fenetre)  
    linky.mainloop()
    #linky.destroy()
    exit(0)

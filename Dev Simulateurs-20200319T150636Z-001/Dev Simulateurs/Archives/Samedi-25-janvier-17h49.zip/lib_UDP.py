#!/usr/bin/env python
# -*-coding:Latin-1 -*

import socket
import sys

class LinkyUDP:

    def __init__(self):
        
        # Ports de communication UDP
        self.port_ER2phone          = 10002 # Port for UDP communications ER to MobilePhone
        self.port_phone2ER          = 10001 # Port for UDP communications MobilePhone to ER

        # Host Name de l'émetteur radio Linky
        self.ER_hostname            = "erlinky.home"

    # -------------------------------------------------------------------------
    # Port à utiliser dans le sens ER (émetteur radio Linky) vers smartphone
    # -------------------------------------------------------------------------
    def get_port_ER2phone(self):
        return(self.port_ER2phone)

    # -------------------------------------------------------------------------
    # Port à utiliser dans le sens smartphone vers ER (émetteur radio Linky)
    # -------------------------------------------------------------------------
    def get_port_phone2ER(self):
        return(self.port_phone2ER)


    # -------------------------------------------------------------------------
    # Get the hostname of the current machine
    # -------------------------------------------------------------------------
    def get_hostname(self):

        # The hostname is usually saved in the file /etc/hosts
        # It can be changed by modifying the file : sudo nano /etc/hosts
        self.hostname               = socket.gethostname()
        print("[*] The name of this machine is : %s "% self.hostname)

        return(self.hostname)

    # -------------------------------------------------------------------------
    # Return the IP address of the livebox
    # -------------------------------------------------------------------------
    def get_ip_of_box(self):
        ip_address_of_livebox  = socket.gethostbyname('livebox.home')
        print("[*] IP address of livebox : %s "% ip_address_of_livebox )

        return(ip_address_of_livebox) 

    # -------------------------------------------------------------------------
    # Sent teleinformation to the smarphone
    # -------------------------------------------------------------------------
    def send_teleinfo(self, teleinfo, address, port):

        # Preparation socket
        sock                = socket.socket(socket.AF_INET, socket.SOCK_DGRAM )
        address_for_socket  = (address, int(port) )

        # Envoi du message
        sent                = sock.sendto ( teleinfo , address_for_socket )
        print("[*] %s envoyé à %s sur port %d " % (teleinfo, address, int(port) ) )

        # Fermeture du socket
        sock.close()

    # -------------------------------------------------------------------------
    # Linky's ER is waiting a message from the smarphone
    # -------------------------------------------------------------------------
    def waiting_message_from_smartphone(self):

        host = ''
        port = self.port_phone2ER
        s    = socket.socket(socket.AF_INET, socket.SOCK_DGRAM )
        s.bind( (host, port) )

        print('[*] Attente requête en provenance du smartphone ...' )
        data, address = s.recvfrom ( 4096 )
        print ('[*] Message reçu : %s ' % data )
        print ('[*] Adresse IP de la source %s : ' % address[0] )
        #print type(address)
        
        # Fermeture du socket
        s.close()

    # ------------------------------------------------------------------
    # Requete de données au compteur Linky depuis le smartphone
    # ------------------------------------------------------------------
    def smartphone_ask_teleinfo_to_erlinky(self):
        address         = 'localhost'
        port            = self.port_phone2ER
        s               = socket.socket(socket.AF_INET, socket.SOCK_DGRAM )
        message         = "Hello ERLinky. Envoye la teleinformation !"
        print('[*] Message envoyé = %s' % message) 
        print('[*] Adresse=%s Port=%d' % (address, port) )
        sent            = s.sendto ( message, (address, port ) )
        s.close()

# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------
if __name__ == '__main__':
    print("[*] Test Linky UDP")

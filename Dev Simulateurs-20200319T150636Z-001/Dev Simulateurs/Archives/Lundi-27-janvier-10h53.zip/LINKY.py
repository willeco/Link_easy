#!/usr/bin/env python
# -*-coding:Latin-1 -*

from threading import Thread
from time      import sleep
from tkinter   import *  

import sys
import json 
import lib_linky_data
import lib_UDP
import time

#from PIL import ImageTk, Image



class InterfaceLinky(Frame):
   
    # ------------------------------------------------------------------ 
    # Initialisation Interface : Création Widgets
    # ------------------------------------------------------------------
    def __init__(self, fenetre):

        Frame.__init__(self, fenetre, width=500, height=500)
        fenetre.title('Compteur Linky')

        # Lecture des données linky stockées dans un fichier texte
        self.linky_data = lib_linky_data.LinkyData()   
        
        # Préparation d'une classe UDP à partir d'une librairie
        self.udp        = lib_UDP.LinkyUDP()

        # Creation des widgets de l'interface Homme Machine
        self.creation_widgets()

        # Création thread (processus) permettant de gérer les communications UDP
        # Notamment l'attente d'une demande de transmisson de téléinformation
        # Puis l'envoi des données de téléinformation vers le smartphone
        self._thread = None
        self.creation_thread()

    # ------------------------------------------------------------------ 
    # Création des Widgets
    # ------------------------------------------------------------------
    def creation_widgets(self):

        self.entry_width = 17

        # Création des variables interface Homme Machine 
        self.var_add_ip_source       = StringVar()
        self.var_add_ip_dest         = StringVar()
        self.var_port_ER2phone       = StringVar()
        self.var_port_phone2ER       = StringVar()
        self.var_mise_en_veille      = IntVar()
        self.var_puissance_apparente = StringVar()
        self.var_label_teleinfo      = StringVar()
        self.var_value_teleinfo      = StringVar()

        # Affectation des variables de l'IHM par défault
        self.var_add_ip_source.set( "localhost")
        self.var_add_ip_dest.set(   "localhost")
        self.var_port_ER2phone.set( self.udp.get_port_ER2phone() )
        self.var_port_phone2ER.set( self.udp.get_port_phone2ER() )
        self.var_puissance_apparente.set("?")
        self.var_mise_en_veille.set(2)

        # Creation Label : Etat de connection et Affichage Label dans la fenetre
        self.widget_label_etat_connection   = Label(self, text="Non connecté à la livebox")
        
        # Creation Entry et Label : Adresse IP et Port de Destination
        self.widget_label_reseau          = Label(self, text="Configuration réseau"      )
        self.widget_label_add_ip_source   = Label(self, text="@ IP module radio") 
        self.widget_label_add_ip_dest     = Label(self, text="@ IP smarphone") 
        self.widget_label_port_ER2phone   = Label(self, text="Port ER vers smarphone") 
        self.widget_label_port_phone2ER   = Label(self, text="Port smarphone vers ER") 
        self.widget_label_parametres      = Label(self, text="Paramètres"      )
        self.widget_label_mise_en_veille  = Label(self, text="Mise en veille (minutes)") 

        self.widget_label_teleinfo        = Label(self, text="Télé-information")
        self.widget_label_papp            = Label(self, text="Puissance apparente (V.A)") 
        self.widget_label_etat            = Label(self, text="Etat")

        self.widget_entry_add_ip_source   = Entry(self, width=self.entry_width, textvariable=self.var_add_ip_source   ) 
        self.widget_entry_add_ip_dest     = Entry(self, width=self.entry_width, textvariable=self.var_add_ip_dest     ) 
        self.widget_entry_port_ER2phone   = Entry(self, width=self.entry_width, textvariable=self.var_port_ER2phone   ) 
        self.widget_entry_port_phone2ER   = Entry(self, width=self.entry_width, textvariable=self.var_port_phone2ER   ) 
        self.widget_entry_mise_en_veille  = Entry(self, width=self.entry_width, textvariable=self.var_mise_en_veille  ) 
        self.widget_entry_papp            = Entry(self, width=self.entry_width, textvariable=self.var_puissance_apparente ) 
        self.widget_entry_label_teleinfo  = Entry(self, width=self.entry_width, textvariable=self.var_label_teleinfo )
        self.widget_entry_value_teleinfo  = Entry(self, width=self.entry_width, textvariable=self.var_value_teleinfo )

        # Création des Widgets Label Etat envoi Trame
        self.widget_label_etat_trame      = Label(self, text="Aucune trame transmise")

        # Modification des couleurs
        self.widget_label_add_ip_source.config(             fg='gray')
        self.widget_label_add_ip_dest.config(               fg='gray')
        self.widget_label_port_ER2phone.config(             fg='gray')
        self.widget_label_port_phone2ER.config(             fg='gray')
        self.widget_label_parametres.config(    bg='gray', fg='white')
        self.widget_label_reseau.config(        bg='gray', fg='white')
        self.widget_entry_add_ip_source.config( bg='gray', fg='white')
        self.widget_entry_add_ip_dest.config(   bg='gray', fg='white')
        self.widget_entry_port_ER2phone.config( bg='gray', fg='white')
        self.widget_entry_port_phone2ER.config( bg='gray', fg='white')
        self.widget_label_teleinfo.config(      bg='gray', fg='white')
        self.widget_label_etat.config(          bg='gray', fg='white')

        
        # Création d'un Widget de Canvas représentant graphiquement le Compteur Linky 
        self.can    = Canvas(fenetre, width=270, height=380, background="lawn green")
        rect1       = self.can.create_rectangle(60,100,200,300, fill="light grey")
        rect2       = self.can.create_rectangle(80,150,180,250, fill="snow4")
        text1       = self.can.create_text(130, 50, text="Linky", fill="snow4", font=("Purisa, 20") )

    
        # Positionnement des widgets (méthode de position Grid)
        self.grid()
        ind_row = 0
        self.widget_label_reseau.grid(           row=ind_row,  columnspan = 2, sticky =  W+E+N+S)
        ind_row += 1
        self.widget_label_add_ip_source.grid(    row=ind_row,  column=0, sticky = W)
        self.widget_entry_add_ip_source.grid(    row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_add_ip_dest.grid(      row=ind_row,  column=0, sticky = W)
        self.widget_entry_add_ip_dest.grid(      row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_port_ER2phone.grid(    row=ind_row,  column=0, sticky = W)
        self.widget_entry_port_ER2phone.grid(    row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_port_phone2ER.grid(    row=ind_row,  column=0, sticky = W)
        self.widget_entry_port_phone2ER.grid(    row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_parametres.grid(       row=ind_row,  columnspan = 2, sticky =  W+E+N+S)
        ind_row += 1
        self.widget_label_mise_en_veille.grid(   row=ind_row,  column=0, sticky = W)
        self.widget_entry_mise_en_veille.grid(   row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_teleinfo.grid(   row=ind_row,  columnspan = 2, sticky =  W+E+N+S)
        ind_row += 1
        self.widget_label_papp.grid(             row=ind_row,  column=0, sticky = W)
        self.widget_entry_papp.grid(             row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_entry_label_teleinfo.grid(   row=ind_row,  column=0, sticky = E)
        self.widget_entry_value_teleinfo.grid(   row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_etat.grid(                row=ind_row,  columnspan = 2, sticky =  W+E+N+S)
        ind_row += 1
        self.widget_label_etat_connection.grid(  row=ind_row,  columnspan = 2)
        ind_row += 1
        self.widget_label_etat_trame.grid(       row=ind_row,  columnspan = 2)
        ind_row += 1

        self.can.grid( row = ind_row )

    # ------------------------------------------------------------------------- 
    # Création Thread permettant de gérer les communications
    # -------------------------------------------------------------------------
    def creation_thread(self):
        
        # Si Thread jamais été cree
        if self._thread is None:
            
            # Création du Thread : la fonction dénommé "action" sera appelée
            # lors du démarrage du thread
            self._thread = Thread(target=self.action)
            
            # Démarrage du Thread : on peut démarrer tout de suite
            self._thread.start()
        
 
    # ------------------------------------------------------------------------- 
    # Thread off
    # -------------------------------------------------------------------------
    def thread_off(self):
        if self._thread is not None:
            self._thread = None

    # ------------------------------------------------------------------------- 
    # Permet de tester si la mise en veille doit être prononcée
    # t_start : entrée contenant la date démarrage de l'envoi des données
    # -------------------------------------------------------------------------
    def continue_to_send(self, t_start):

        # Récupération du temps courant en secondes
        current_time        = time.time()

        # Calcul de la durée écoulée
        delta_min       = int( (current_time - t_start)/ 60.0 )

        # Récupération du champs spécifiant la durée de mise en veille
        delay_mise_veille   = int(self.var_mise_en_veille.get())

        # Test : A t-on dépasser la durée
        return( delta_min < delay_mise_veille )  

    # ------------------------------------------------------------------------- 
    # Call-back action (Gère les communications)
    # -------------------------------------------------------------------------
    def action(self):
        
        # Attente bloquante d'une requête en provenance du smartphone 
        self.widget_label_etat_connection["text"] = "Attente requête du smartphone ..."
        self.udp.waiting_message_from_smartphone()

        self.widget_label_etat_connection["text"] = "Requête reçu du smartphone "

        # Récupération du temps 
        t_start = time.time()

        while self.continue_to_send(t_start):
            i = 0

            # Boucle sur toutes les données de la téléinformation contenue dans une liste
            for teleinfo in self.linky_data.get_teleinfo():

                # Pour données de téléinformatipn, conversion téléinformation au format Json
                json_tele = json.loads(teleinfo)

                # Boucle sur les clés (normalement, il n'y a qu'une)
                for cle in json_tele.keys():

                    # Affichage de la téléinformation sur l'IHM
                    self.var_label_teleinfo.set(cle)
                    self.var_value_teleinfo.set(json_tele[cle])

                    # Identification Puissance apparente et affichage
                    if cle == "PAPP":

                        # Mise à jour du champ puissance apparente 
                        self.var_puissance_apparente.set( json_tele[cle] )
            
                        # Envoi de la télé-information
                        self.udp.send_teleinfo(str(json.dumps(json_tele)), 
                                                self.var_add_ip_dest.get(), 
                                                self.var_port_ER2phone.get() )
                        

                # Mise à jour nombre champs teleinfo traités
                self.widget_label_etat_trame["text"] = "Playing... (count: {})".format(i)

                # Pause 
                sleep(0.01)
                i+= 1
       
        print("[*] Arrêt transmission de la téléinformation")     
        self.widget_label_etat_trame["text"] = "Stopped."
        
# -----------------------------------------------------------------------------
# Test
# ----------------------------------------------------------------------------- 
if __name__ == '__main__':
    fenetre     = Tk()
    linky       = InterfaceLinky(fenetre)  
    linky.mainloop()
    linky.thread_off()
    exit(0)

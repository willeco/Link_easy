#!/usr/bin/env python
# -*-coding:Latin-1 -*

from threading import Thread
from time      import sleep
from tkinter   import *  

import sys
import json 
import lib_linky_data
import lib_UDP
import time
import socket

class InterfacePhone(Frame):
   
    # ------------------------------------------------------------------ 
    # Initialisation Interface : Creation Widgets
    # ------------------------------------------------------------------
    def __init__(self, fenetre):

        Frame.__init__(self, fenetre, width=500, height=500)
        fenetre.title('Smartphone')
        
        # Préparation class UDP
        self.udp        = lib_UDP.LinkyUDP()

        # Creation des widgets
        self.creation_widgets()

        # Initialisation du thread
        self._thread            = None
        self.nb_trames_recues   = 0

    def creation_widgets(self):

        self.entry_width = 17

        # Création des variables interface Homme Machine 
        self.var_add_ip_source       = StringVar()
        self.var_add_ip_dest         = StringVar()
        self.var_port_ER2phone       = StringVar()
        self.var_port_phone2ER       = StringVar()

        self.var_puissance_apparente = StringVar()


        # Affectation des variables de l'IHM par défault
        self.var_add_ip_source.set("localhost")
        self.var_add_ip_dest.set("localhost")
        self.var_port_ER2phone.set(self.udp.get_port_ER2phone() )
        self.var_port_phone2ER.set(self.udp.get_port_phone2ER() )
        self.var_puissance_apparente.set("?")
 

        # Creation Label : Etat de connection et Affichage Label dans la fenetre
        self.widget_label_etat_connection   = Label(self, text="Non connecté à l'émetteur radio Linky")
        
        # Creation Entry et Label : Adresse IP et Port de Destination
        self.widget_label_reseau          = Label(self, text="Configuration réseau"      )
        self.widget_label_add_ip_source   = Label(self, text="Adresse IP du module radio") 
        self.widget_label_add_ip_dest     = Label(self, text="Adresse IP du smarphone"   ) 
        self.widget_label_port_ER2phone   = Label(self, text="Port : ER vers smarphone"  ) 
        self.widget_label_port_phone2ER   = Label(self, text="Port : smarphone vers ER"  ) 
        self.widget_label_teleinfo        = Label(self, text="Données reçues de télé-information")
        self.widget_label_etat            = Label(self, text="Etat de réception"                 )
        self.widget_label_papp            = Label(self, text="Puissance apparente (V.A)" )
 
        self.widget_entry_add_ip_source   = Entry(self, width=self.entry_width, textvariable=self.var_add_ip_source   ) 
        self.widget_entry_add_ip_dest     = Entry(self, width=self.entry_width, textvariable=self.var_add_ip_dest     ) 
        self.widget_entry_port_ER2phone   = Entry(self, width=self.entry_width, textvariable=self.var_port_ER2phone   ) 
        self.widget_entry_port_phone2ER   = Entry(self, width=self.entry_width, textvariable=self.var_port_phone2ER   ) 
        self.widget_entry_papp            = Entry(self, width=self.entry_width, textvariable=self.var_puissance_apparente ) 

        self.widget_label_add_ip_source.config( fg='gray')
        self.widget_label_add_ip_dest.config(          fg='gray')
        self.widget_label_port_ER2phone.config(        fg='gray')
        self.widget_label_port_phone2ER.config(        fg='gray')
        self.widget_label_reseau.config(        bg='gray', fg='white')
        self.widget_entry_add_ip_source.config( bg='gray', fg='white')
        self.widget_entry_add_ip_dest.config(   bg='gray', fg='white')
        self.widget_entry_port_ER2phone.config( bg='gray', fg='white')
        self.widget_entry_port_phone2ER.config( bg='gray', fg='white')
        self.widget_label_teleinfo.config(      bg='gray', fg='white')
        self.widget_label_etat.config(          bg='gray', fg='white')

        # Creation des Widgets Label Etat envoi Trame
        self.widget_label_etat_trame      = Label(self, text="Aucune trame reçue")

        # Création des Widgets Bouton ON
        self.widget_on_button             = Button(self, text="Demande de télé-information",  command=self.callback_on)
        self.widget_on_button.config( width=self.entry_width-3)
        
        # Création d'un Widget représentant le Compteur Linky 
        self.can    = Canvas(fenetre, width=310, height=100, background="black")
    
        # Positionnement des widgets
        self.grid()
        ind_row = 0
        self.widget_label_reseau.grid(           row=ind_row,  columnspan = 2, sticky =  W+E+N+S)
        ind_row += 1
        self.widget_label_add_ip_source.grid(    row=ind_row,  column=0, sticky = W)
        self.widget_entry_add_ip_source.grid(    row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_add_ip_dest.grid(      row=ind_row,  column=0, sticky = W)
        self.widget_entry_add_ip_dest.grid(      row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_port_ER2phone.grid(    row=ind_row,  column=0, sticky = W)
        self.widget_entry_port_ER2phone.grid(    row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_port_phone2ER.grid(    row=ind_row,  column=0, sticky = W)
        self.widget_entry_port_phone2ER.grid(    row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_label_etat.grid(             row=ind_row,  columnspan = 2, sticky =  W+E+N+S)
        ind_row += 1
        self.widget_label_etat_connection.grid(  row=ind_row,  columnspan = 2)
        ind_row += 1
        self.widget_label_etat_trame.grid(       row=ind_row,  columnspan = 2)
        ind_row += 1

        self.widget_label_teleinfo.grid(         row=ind_row,  columnspan = 2, sticky =  W+E+N+S)
        ind_row += 1
        self.widget_label_papp.grid(             row=ind_row,  column=0, sticky = W)
        self.widget_entry_papp.grid(             row=ind_row,  column=1, sticky = W)
        ind_row += 1
        self.widget_on_button.grid(              row=ind_row,  columnspan = 2, sticky =W+E+N+S)
        ind_row += 1


        self.can.grid( row = ind_row )

    # ------------------------------------------------------------------------- 
    # Call-back ON (fonction appelée lors de l'appui sur le bouton ON)
    # -------------------------------------------------------------------------
    def callback_on(self):
        
        # Demande de téléinformation au module Linky
        self.udp.smartphone_ask_teleinfo_to_erlinky()

        # Si Thread jamais été créée
        if self._thread is None:
            
            # Création du Thread : la fonction "réception" sera appelée
            self._thread = Thread(target=self.reception)
            
            # Démarrage du Thread de réception des données de téléinformation
            self._thread.start()
        
    # ------------------------------------------------------------------------- 
    # Call-back action (Thread crée lors de l'appui sur le bouton ON)
    # -------------------------------------------------------------------------
    def reception(self):

        address         = self.var_add_ip_source.get()
        port            = self.udp.get_port_ER2phone()
        server_address  = (address, port )
        s               = socket.socket(socket.AF_INET, socket.SOCK_DGRAM )
        s.bind(server_address)

        # Affichage Etat connection
        self.widget_label_etat_connection["text"] = "Attente de télé-information ..."

        while True:
            # Limiter la taille des données en réception à 8176 octets (4096 suffit)
            data, address = s.recvfrom ( 4096 )
            print("[*] Recu message %s depuis %s (Port Tx=%d)" % ( data, address[0], address[1] ) )

            # Mise au Format JSON de la téléinformation
            json_tele = json.loads(data)
            
            # Boucle sur les clés (normalement, il n'y en a qu'une)
            for cle in json_tele.keys():
                if cle == "PAPP":
                    self.var_puissance_apparente.set( json_tele[cle] )                


            # Affichage état de réception
            self.nb_trames_recues += 1
            self.widget_label_etat_trame["text"] = ("%d trames reçues" % self.nb_trames_recues)

            if (self.nb_trames_recues == 1):
                self.widget_label_etat_connection["text"] = "Réception télé-formation en cours"

        s.close()
        
# -----------------------------------------------------------------------------
# Test
# ----------------------------------------------------------------------------- 
if __name__ == '__main__':
    fenetre     = Tk()
    phone       = InterfacePhone(fenetre)  
    phone.mainloop()
    exit(0)

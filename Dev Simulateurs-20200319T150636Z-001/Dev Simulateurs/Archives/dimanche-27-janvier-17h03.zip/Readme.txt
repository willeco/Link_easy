Readme
------

1°) Pour simuler un compteur Linky relié au raspberry PI retransmettant la téléinformation
    par UDP, ouvrir une autre fenetre terminal et tapez :
    python LINKY.py

    Appuyer sur le bouton POWER ON afin de mettre l'ERLinky en attente du requete du smartphone

2°) Pour simuler un smartphone, ouvrir une autre fenetre terminal et tapez 
    python PHONE.py 
    
    Le smartphhone va envoyer une requete au Linky pour demander la téléinformation


